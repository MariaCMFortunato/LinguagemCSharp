﻿namespace GestaoFormandos02
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPrincipal));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.formandosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inserirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.atualizarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.apagarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.listarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nacionalidadeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inserirToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.atualizarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.apagarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.listarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.areaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inserirToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.atualizarToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.apagarToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.listarToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.formadorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inserirToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.atualizarToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.apagarToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.listarToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.exportaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dadosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonLogOut = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabelUser = new System.Windows.Forms.ToolStripLabel();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.formandosToolStripMenuItem,
            this.nacionalidadeToolStripMenuItem,
            this.areaToolStripMenuItem,
            this.formadorToolStripMenuItem,
            this.exportaçãoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(880, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // formandosToolStripMenuItem
            // 
            this.formandosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inserirToolStripMenuItem,
            this.atualizarToolStripMenuItem,
            this.apagarToolStripMenuItem,
            this.toolStripMenuItem1,
            this.listarToolStripMenuItem});
            this.formandosToolStripMenuItem.Name = "formandosToolStripMenuItem";
            this.formandosToolStripMenuItem.Size = new System.Drawing.Size(74, 20);
            this.formandosToolStripMenuItem.Text = "&Formando";
            // 
            // inserirToolStripMenuItem
            // 
            this.inserirToolStripMenuItem.Image = global::GestaoFormandos02.Properties.Resources.Add;
            this.inserirToolStripMenuItem.Name = "inserirToolStripMenuItem";
            this.inserirToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.inserirToolStripMenuItem.Text = "&Inserir";
            this.inserirToolStripMenuItem.Click += new System.EventHandler(this.inserirToolStripMenuItem_Click);
            // 
            // atualizarToolStripMenuItem
            // 
            this.atualizarToolStripMenuItem.Image = global::GestaoFormandos02.Properties.Resources.Update;
            this.atualizarToolStripMenuItem.Name = "atualizarToolStripMenuItem";
            this.atualizarToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.atualizarToolStripMenuItem.Text = "&Atualizar";
            this.atualizarToolStripMenuItem.Click += new System.EventHandler(this.atualizarToolStripMenuItem_Click);
            // 
            // apagarToolStripMenuItem
            // 
            this.apagarToolStripMenuItem.Image = global::GestaoFormandos02.Properties.Resources.Delete;
            this.apagarToolStripMenuItem.Name = "apagarToolStripMenuItem";
            this.apagarToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.apagarToolStripMenuItem.Text = "A&pagar";
            this.apagarToolStripMenuItem.Click += new System.EventHandler(this.apagarToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(177, 6);
            // 
            // listarToolStripMenuItem
            // 
            this.listarToolStripMenuItem.Image = global::GestaoFormandos02.Properties.Resources.List;
            this.listarToolStripMenuItem.Name = "listarToolStripMenuItem";
            this.listarToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.listarToolStripMenuItem.Text = "&Listar";
            this.listarToolStripMenuItem.Click += new System.EventHandler(this.listarToolStripMenuItem_Click);
            // 
            // nacionalidadeToolStripMenuItem
            // 
            this.nacionalidadeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inserirToolStripMenuItem1,
            this.atualizarToolStripMenuItem1,
            this.apagarToolStripMenuItem1,
            this.toolStripMenuItem3,
            this.listarToolStripMenuItem1});
            this.nacionalidadeToolStripMenuItem.Name = "nacionalidadeToolStripMenuItem";
            this.nacionalidadeToolStripMenuItem.Size = new System.Drawing.Size(95, 20);
            this.nacionalidadeToolStripMenuItem.Text = "&Nacionalidade";
            // 
            // inserirToolStripMenuItem1
            // 
            this.inserirToolStripMenuItem1.Image = global::GestaoFormandos02.Properties.Resources.Add;
            this.inserirToolStripMenuItem1.Name = "inserirToolStripMenuItem1";
            this.inserirToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.inserirToolStripMenuItem1.Text = "&Inserir";
            this.inserirToolStripMenuItem1.Click += new System.EventHandler(this.inserirToolStripMenuItem1_Click);
            // 
            // atualizarToolStripMenuItem1
            // 
            this.atualizarToolStripMenuItem1.Image = global::GestaoFormandos02.Properties.Resources.Update;
            this.atualizarToolStripMenuItem1.Name = "atualizarToolStripMenuItem1";
            this.atualizarToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.atualizarToolStripMenuItem1.Text = "&Atualizar";
            this.atualizarToolStripMenuItem1.Click += new System.EventHandler(this.atualizarToolStripMenuItem1_Click);
            // 
            // apagarToolStripMenuItem1
            // 
            this.apagarToolStripMenuItem1.Image = global::GestaoFormandos02.Properties.Resources.Delete;
            this.apagarToolStripMenuItem1.Name = "apagarToolStripMenuItem1";
            this.apagarToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.apagarToolStripMenuItem1.Text = "A&pagar";
            this.apagarToolStripMenuItem1.Click += new System.EventHandler(this.apagarToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(177, 6);
            // 
            // listarToolStripMenuItem1
            // 
            this.listarToolStripMenuItem1.Image = global::GestaoFormandos02.Properties.Resources.List;
            this.listarToolStripMenuItem1.Name = "listarToolStripMenuItem1";
            this.listarToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.listarToolStripMenuItem1.Text = "&Listar";
            this.listarToolStripMenuItem1.Click += new System.EventHandler(this.listarToolStripMenuItem1_Click);
            // 
            // areaToolStripMenuItem
            // 
            this.areaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inserirToolStripMenuItem2,
            this.atualizarToolStripMenuItem2,
            this.apagarToolStripMenuItem2,
            this.toolStripMenuItem2,
            this.listarToolStripMenuItem2});
            this.areaToolStripMenuItem.Name = "areaToolStripMenuItem";
            this.areaToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.areaToolStripMenuItem.Text = "&Area";
            // 
            // inserirToolStripMenuItem2
            // 
            this.inserirToolStripMenuItem2.Image = global::GestaoFormandos02.Properties.Resources.Add;
            this.inserirToolStripMenuItem2.Name = "inserirToolStripMenuItem2";
            this.inserirToolStripMenuItem2.Size = new System.Drawing.Size(180, 22);
            this.inserirToolStripMenuItem2.Text = "&Inserir";
            this.inserirToolStripMenuItem2.Click += new System.EventHandler(this.inserirToolStripMenuItem2_Click);
            // 
            // atualizarToolStripMenuItem2
            // 
            this.atualizarToolStripMenuItem2.Image = global::GestaoFormandos02.Properties.Resources.Update;
            this.atualizarToolStripMenuItem2.Name = "atualizarToolStripMenuItem2";
            this.atualizarToolStripMenuItem2.Size = new System.Drawing.Size(180, 22);
            this.atualizarToolStripMenuItem2.Text = "&Atualizar";
            this.atualizarToolStripMenuItem2.Click += new System.EventHandler(this.atualizarToolStripMenuItem2_Click);
            // 
            // apagarToolStripMenuItem2
            // 
            this.apagarToolStripMenuItem2.Image = global::GestaoFormandos02.Properties.Resources.Delete;
            this.apagarToolStripMenuItem2.Name = "apagarToolStripMenuItem2";
            this.apagarToolStripMenuItem2.Size = new System.Drawing.Size(180, 22);
            this.apagarToolStripMenuItem2.Text = "A&pagar";
            this.apagarToolStripMenuItem2.Click += new System.EventHandler(this.apagarToolStripMenuItem2_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(177, 6);
            // 
            // listarToolStripMenuItem2
            // 
            this.listarToolStripMenuItem2.Image = global::GestaoFormandos02.Properties.Resources.List;
            this.listarToolStripMenuItem2.Name = "listarToolStripMenuItem2";
            this.listarToolStripMenuItem2.Size = new System.Drawing.Size(180, 22);
            this.listarToolStripMenuItem2.Text = "&Listar";
            this.listarToolStripMenuItem2.Click += new System.EventHandler(this.listarToolStripMenuItem2_Click);
            // 
            // formadorToolStripMenuItem
            // 
            this.formadorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inserirToolStripMenuItem3,
            this.atualizarToolStripMenuItem3,
            this.apagarToolStripMenuItem3,
            this.toolStripMenuItem4,
            this.listarToolStripMenuItem3});
            this.formadorToolStripMenuItem.Name = "formadorToolStripMenuItem";
            this.formadorToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.formadorToolStripMenuItem.Text = "F&ormador";
            // 
            // inserirToolStripMenuItem3
            // 
            this.inserirToolStripMenuItem3.Image = global::GestaoFormandos02.Properties.Resources.Add;
            this.inserirToolStripMenuItem3.Name = "inserirToolStripMenuItem3";
            this.inserirToolStripMenuItem3.Size = new System.Drawing.Size(180, 22);
            this.inserirToolStripMenuItem3.Text = "&Inserir";
            this.inserirToolStripMenuItem3.Click += new System.EventHandler(this.inserirToolStripMenuItem3_Click);
            // 
            // atualizarToolStripMenuItem3
            // 
            this.atualizarToolStripMenuItem3.Image = global::GestaoFormandos02.Properties.Resources.Update;
            this.atualizarToolStripMenuItem3.Name = "atualizarToolStripMenuItem3";
            this.atualizarToolStripMenuItem3.Size = new System.Drawing.Size(180, 22);
            this.atualizarToolStripMenuItem3.Text = "&Atualizar";
            this.atualizarToolStripMenuItem3.Click += new System.EventHandler(this.atualizarToolStripMenuItem3_Click);
            // 
            // apagarToolStripMenuItem3
            // 
            this.apagarToolStripMenuItem3.Image = global::GestaoFormandos02.Properties.Resources.Delete;
            this.apagarToolStripMenuItem3.Name = "apagarToolStripMenuItem3";
            this.apagarToolStripMenuItem3.Size = new System.Drawing.Size(180, 22);
            this.apagarToolStripMenuItem3.Text = "A&pagar";
            this.apagarToolStripMenuItem3.Click += new System.EventHandler(this.apagarToolStripMenuItem3_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(177, 6);
            // 
            // listarToolStripMenuItem3
            // 
            this.listarToolStripMenuItem3.Image = global::GestaoFormandos02.Properties.Resources.List;
            this.listarToolStripMenuItem3.Name = "listarToolStripMenuItem3";
            this.listarToolStripMenuItem3.Size = new System.Drawing.Size(180, 22);
            this.listarToolStripMenuItem3.Text = "&Listar";
            this.listarToolStripMenuItem3.Click += new System.EventHandler(this.listarToolStripMenuItem3_Click);
            // 
            // exportaçãoToolStripMenuItem
            // 
            this.exportaçãoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dadosToolStripMenuItem});
            this.exportaçãoToolStripMenuItem.Name = "exportaçãoToolStripMenuItem";
            this.exportaçãoToolStripMenuItem.Size = new System.Drawing.Size(78, 20);
            this.exportaçãoToolStripMenuItem.Text = "&Exportação";
            // 
            // dadosToolStripMenuItem
            // 
            this.dadosToolStripMenuItem.Image = global::GestaoFormandos02.Properties.Resources.file;
            this.dadosToolStripMenuItem.Name = "dadosToolStripMenuItem";
            this.dadosToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.dadosToolStripMenuItem.Text = "&Dados";
            this.dadosToolStripMenuItem.Click += new System.EventHandler(this.dadosToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonLogOut,
            this.toolStripLabelUser});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.toolStrip1.Size = new System.Drawing.Size(880, 25);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButtonLogOut
            // 
            this.toolStripButtonLogOut.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonLogOut.Image = global::GestaoFormandos02.Properties.Resources.Exit;
            this.toolStripButtonLogOut.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonLogOut.Name = "toolStripButtonLogOut";
            this.toolStripButtonLogOut.Size = new System.Drawing.Size(23, 22);
            this.toolStripButtonLogOut.Text = "LogOut";
            this.toolStripButtonLogOut.Click += new System.EventHandler(this.toolStripButtonLogOut_Click);
            // 
            // toolStripLabelUser
            // 
            this.toolStripLabelUser.Name = "toolStripLabelUser";
            this.toolStripLabelUser.Size = new System.Drawing.Size(103, 22);
            this.toolStripLabelUser.Text = "toolStripLabelUser";
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(880, 525);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormPrincipal";
            this.Text = "Projeto 1: Gestão Formandos";
            this.Load += new System.EventHandler(this.FormPrincipal_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem formandosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem atualizarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem apagarToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem listarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inserirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nacionalidadeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inserirToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem atualizarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem apagarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem listarToolStripMenuItem1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabelUser;
        private System.Windows.Forms.ToolStripButton toolStripButtonLogOut;
        private System.Windows.Forms.ToolStripMenuItem areaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formadorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dadosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inserirToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem atualizarToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem apagarToolStripMenuItem2;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem listarToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem inserirToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem atualizarToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem apagarToolStripMenuItem3;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem listarToolStripMenuItem3;
    }
}